﻿"""
ThermostatServer-Simulator (Enhanced)
Reads thermostat status lines over serial and prints validated output.

Improvements:
- Input validation and parsing
- Clearer output formatting
- Safer failure behavior (won't crash on malformed lines)
"""

import time
from typing import Optional

try:
    import serial  # type: ignore
except Exception:
    serial = None


SERIAL_PORT = "/dev/ttyUSB0"
BAUDRATE = 115200
TIMEOUT_SEC = 1


def parse_status_line(line: str) -> Optional[dict]:
    """
    Expected format: state,tempF,setpoint
    Example: heat,71.23,72
    """
    parts = [p.strip() for p in line.split(",")]
    if len(parts) != 3:
        return None

    state = parts[0].lower()
    if state not in {"off", "heat", "cool"}:
        return None

    try:
        temp_f = float(parts[1])
        setpoint = int(parts[2])
    except ValueError:
        return None

    return {"state": state, "temp_f": temp_f, "setpoint": setpoint}


def main() -> None:
    if serial is None:
        print("pyserial not installed; cannot read serial. Exiting.")
        return

    try:
        ser = serial.Serial(
            port=SERIAL_PORT,
            baudrate=BAUDRATE,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            bytesize=serial.EIGHTBITS,
            timeout=TIMEOUT_SEC,
        )
        print(f"Listening on {SERIAL_PORT} @ {BAUDRATE} baud (CTRL-C to stop)")
    except Exception as e:
        print(f"Failed to open serial port: {e}")
        return

    try:
        while True:
            raw = ser.readline()
            if not raw:
                time.sleep(0.05)
                continue

            line = raw.decode("utf-8", errors="ignore").strip().lower()
            if not line:
                continue

            parsed = parse_status_line(line)
            if parsed is None:
                print(f"[WARN] Malformed line ignored: {line}")
                continue

            print(
                f"STATE={parsed['state'].upper()} | "
                f"TEMP={parsed['temp_f']:.2f}F | "
                f"SETPOINT={parsed['setpoint']}F"
            )
    except KeyboardInterrupt:
        print("\nExiting cleanly...")
    finally:
        try:
            ser.close()
        except Exception:
            pass


if __name__ == "__main__":
    main()
