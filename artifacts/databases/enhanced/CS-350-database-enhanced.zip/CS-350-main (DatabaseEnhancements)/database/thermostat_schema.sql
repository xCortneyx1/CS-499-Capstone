-- Smart Thermostat Database Schema
-- CS 499 Milestone Four – Database Enhancement

CREATE TABLE IF NOT EXISTS thermostat_readings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    temperature REAL NOT NULL,
    setpoint REAL NOT NULL,
    mode TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS system_status (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    system_state TEXT NOT NULL,
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
);
