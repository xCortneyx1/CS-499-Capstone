CS 499 Milestone Four – Enhancement Three: Databases
Enhanced Smart Thermostat Artifact

This folder contains the enhanced version of the CS 350 Smart Thermostat project,
updated for CS 499 to demonstrate applied database design and data persistence.

A SQLite database is used to persist thermostat temperature readings,
operational modes, setpoint values, and timestamps. The database schema
documents the structure of stored data, and configuration files define
database access paths.

These enhancements demonstrate applied database design and persistent
data management suitable for inclusion in a professional ePortfolio.


Database Enhancements
---------------------
The Smart Thermostat was enhanced to include a SQLite database for persistent
storage of system data. The database stores thermostat temperature readings,
setpoint values, operational modes, and timestamps, allowing data to be retained
across program executions.

The database schema defines structured tables to organize system readings and
status information in a clear and maintainable format. This enhancement replaces
reliance on transient in-memory data with persistent storage, improving system
reliability and realism.

Database Files
--------------
- database/thermostat.db
  SQLite database file containing structured thermostat data.

- database/thermostat_schema.sql
  SQL schema documenting the structure of the database tables.

Configuration
-------------
Database access is configured using a dedicated configuration file that defines
the database path, supporting clean separation of concerns and easier maintenance.

Outcome
-------
These enhancements demonstrate my ability to design and integrate database
solutions, manage persistent application data, and apply foundational database
principles within an existing software system. The enhanced artifact reflects
professional software development practices suitable for inclusion in my CS 499
ePortfolio.
