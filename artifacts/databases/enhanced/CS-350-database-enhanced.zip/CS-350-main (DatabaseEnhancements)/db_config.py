﻿"""
Database configuration for Smart Thermostat
CS 499 Milestone Four – Database Enhancement
"""

DATABASE_TYPE = "SQLite"
DATABASE_PATH = "database/thermostat.db"
