# CS 350 – Emerging Systems Architecture Portfolio

## Project Summary
In this course, I developed a smart thermostat prototype using a Raspberry Pi and multiple hardware peripherals. The goal of the project was to simulate the low-level functionality of a commercial smart thermostat, including temperature sensing, user input, state management, and serial communication to represent data being sent to a server. This project demonstrates how embedded systems integrate software logic with physical hardware components while meeting specific business and technical requirements.

## What I Did Well
One of my strongest areas in this project was integrating multiple peripherals into a single, cohesive system. I successfully implemented a state machine to manage the thermostat’s operating modes (off, heat, cool) and connected that logic to real hardware behavior using LEDs, buttons, and a temperature sensor. I also handled UART communication to simulate cloud/server data output and added console-based display output when hardware limitations were encountered. Debugging and adapting to hardware issues without breaking functionality was a major strength in this project.

## Areas for Improvement
If I were to continue developing this project, I would improve my initial hardware validation and testing process to identify defective components earlier. I would also spend more time refining error handling and edge cases related to sensor communication and timing. With additional time, I would explore power optimization and expand the system to support real Wi-Fi cloud connectivity instead of simulated serial output.

## Tools and Resources Added to My Support Network
Through this project, I expanded my support network to include Raspberry Pi documentation, Adafruit hardware libraries, GPIOZero documentation, I2C debugging tools, and state machine design resources. I also gained more confidence using Linux command-line tools, SSH, and GitHub for version control and portfolio development.

## Transferable Skills
The skills I gained in this project are highly transferable to future coursework and professional projects. These include embedded system design, state machine implementation, hardware/software integration, peripheral communication (GPIO, I2C, UART), debugging real hardware issues, and documenting technical decisions clearly. These skills apply directly to IoT, systems programming, and low-level software engineering roles.

## Maintainability, Readability, and Adaptability
I designed the project with maintainability in mind by organizing functionality into clear methods and classes, using consistent naming conventions, and adding descriptive comments throughout the code. The use of a state machine makes the system easy to extend with additional states or features in the future. Separating hardware control logic from display and communication logic also makes the code adaptable to new hardware platforms or cloud-based extensions.

## CS 499 Milestone Two – Software Design and Engineering Enhancements

For CS 499 (Computer Science Capstone), this project was enhanced to better reflect
professional software design and engineering practices suitable for inclusion in an
ePortfolio.

### Enhancement Focus
The enhancements for Milestone Two focused on improving **design quality, robustness,
and maintainability** rather than adding new features. The original functionality and
behavior of the thermostat were preserved.

### Key Enhancements Implemented
- **Improved separation of concerns:** Core responsibilities such as configuration,
  hardware interaction, control logic, display management, and serial reporting were
  reorganized to reduce tight coupling and improve clarity.
- **Centralized configuration:** GPIO pins, timing intervals, temperature limits, and
  serial settings were moved into named configuration values to eliminate hard-coded
  “magic numbers” and improve portability.
- **Defensive programming and robustness:** Added validation for temperature readings,
  safe clamping of setpoint values, and safer handling of serial communication to prevent
  runtime failures.
- **Graceful shutdown and thread lifecycle handling:** Improved cleanup of threads,
  display resources, LEDs, and serial connections to ensure clean program termination.
- **Simulation-friendly execution:** Added fallback behavior that allows the code to run
  without physical hardware, improving testability and portfolio review.

### Outcome
These enhancements strengthen the project as a professional portfolio artifact by
demonstrating software engineering practices such as modular design, defensive coding,
configuration management, and lifecycle control. The project is now easier to maintain,
extend, and adapt to future hardware or cloud-based enhancements while preserving its
original embedded-system behavior.
