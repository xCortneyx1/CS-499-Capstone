﻿"""
CS 350 Thermostat (Enhanced for CS 499 Milestone Two)
Enhancement Focus: Software Design & Engineering

Key Improvements:
- Separation of concerns (config, hardware adapters, controller, display loop)
- Centralized configuration (no magic numbers)
- Defensive programming (input validation, setpoint clamping, safer serial writes)
- Graceful shutdown (thread lifecycle, resource cleanup)
- Optional simulation mode if hardware libraries are unavailable
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from math import floor
from threading import Thread, Event
from time import sleep
from typing import Optional


# -----------------------------
# Configuration
# -----------------------------
@dataclass(frozen=True)
class Config:
    # GPIO pins
    RED_LED_PIN: int = 18
    BLUE_LED_PIN: int = 23
    MODE_BUTTON_PIN: int = 24
    INC_BUTTON_PIN: int = 25
    DEC_BUTTON_PIN: int = 12

    # LCD pins (board pin names, used by adafruit_character_lcd)
    LCD_RS: str = "D17"
    LCD_EN: str = "D27"
    LCD_D4: str = "D5"
    LCD_D5: str = "D6"   # fixed
    LCD_D6: str = "D13"
    LCD_D7: str = "D26"
    LCD_COLUMNS: int = 16
    LCD_ROWS: int = 2

    # Serial settings
    SERIAL_PORT: str = "/dev/ttyAMA0"
    SERIAL_BAUD: int = 115200
    SERIAL_TIMEOUT_SEC: int = 1

    # Timing
    DISPLAY_REFRESH_SEC: float = 1.0
    SERVER_REPORT_EVERY_SEC: int = 30

    # Thermostat limits
    DEFAULT_SETPOINT_F: int = 72
    MIN_SETPOINT_F: int = 50
    MAX_SETPOINT_F: int = 90

    # Temperature sanity range (F)
    MIN_TEMP_F: float = -40.0
    MAX_TEMP_F: float = 150.0

    DEBUG: bool = True


CFG = Config()


# -----------------------------
# Optional hardware imports
# -----------------------------
HARDWARE_AVAILABLE = True
try:
    from statemachine import StateMachine, State  # type: ignore
    import board  # type: ignore
    import digitalio  # type: ignore
    import adafruit_ahtx0  # type: ignore
    import adafruit_character_lcd.character_lcd as characterlcd  # type: ignore
    import serial  # type: ignore
    from gpiozero import Button, PWMLED  # type: ignore
except Exception:
    HARDWARE_AVAILABLE = False


# -----------------------------
# Utilities
# -----------------------------
def clamp(value: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, value))


def is_valid_temp_f(temp_f: Optional[float]) -> bool:
    if temp_f is None:
        return False
    return CFG.MIN_TEMP_F <= temp_f <= CFG.MAX_TEMP_F


def debug(msg: str) -> None:
    if CFG.DEBUG:
        print(msg)


# -----------------------------
# Display Adapter
# -----------------------------
class ManagedDisplay:
    """
    Manages the 16x2 character LCD.
    If LCD hardware is unavailable, falls back to console output.
    """

    def __init__(self) -> None:
        self._lcd = None
        self._gpio_lines = []

        if not HARDWARE_AVAILABLE:
            debug("[Display] Hardware libs not available. Using console output.")
            return

        try:
            # Map board pin names from Config to board attributes safely.
            rs = getattr(board, CFG.LCD_RS)
            en = getattr(board, CFG.LCD_EN)
            d4 = getattr(board, CFG.LCD_D4)
            d5 = getattr(board, CFG.LCD_D5)
            d6 = getattr(board, CFG.LCD_D6)
            d7 = getattr(board, CFG.LCD_D7)

            self.lcd_rs = digitalio.DigitalInOut(rs)
            self.lcd_en = digitalio.DigitalInOut(en)
            self.lcd_d4 = digitalio.DigitalInOut(d4)
            self.lcd_d5 = digitalio.DigitalInOut(d5)
            self.lcd_d6 = digitalio.DigitalInOut(d6)
            self.lcd_d7 = digitalio.DigitalInOut(d7)

            self._gpio_lines = [
                self.lcd_rs, self.lcd_en, self.lcd_d4,
                self.lcd_d5, self.lcd_d6, self.lcd_d7
            ]

            self._lcd = characterlcd.Character_LCD_Mono(
                self.lcd_rs,
                self.lcd_en,
                self.lcd_d4,
                self.lcd_d5,
                self.lcd_d6,
                self.lcd_d7,
                CFG.LCD_COLUMNS,
                CFG.LCD_ROWS,
            )
            self._lcd.clear()
            debug("[Display] LCD initialized.")
        except Exception as e:
            debug(f"[Display] LCD init failed. Using console output. Error: {e}")
            self._lcd = None

    def update(self, line1: str, line2: str) -> None:
        """
        Update LCD (or console) with two lines.
        """
        line1 = (line1[:CFG.LCD_COLUMNS]).ljust(CFG.LCD_COLUMNS)
        line2 = (line2[:CFG.LCD_COLUMNS]).ljust(CFG.LCD_COLUMNS)

        if self._lcd is None:
            print("LCD Line 1:", line1.strip())
            print("LCD Line 2:", line2.strip())
            print("-" * 30)
            return

        try:
            self._lcd.clear()
            self._lcd.message = f"{line1}\n{line2}"
        except Exception as e:
            debug(f"[Display] Update failed: {e}")

    def cleanup(self) -> None:
        if self._lcd is not None:
            try:
                self._lcd.clear()
            except Exception:
                pass
        for line in self._gpio_lines:
            try:
                line.deinit()
            except Exception:
                pass
        debug("[Display] Cleaned up.")


# -----------------------------
# Sensor Adapter
# -----------------------------
class TemperatureSensor:
    """
    Provides temperature readings in Fahrenheit.
    Uses AHTx0 if available; otherwise provides simulated readings.
    """

    def __init__(self) -> None:
        self.last_good_temp_f: float = float(CFG.DEFAULT_SETPOINT_F)

        if HARDWARE_AVAILABLE:
            try:
                i2c = board.I2C()
                self._sensor = adafruit_ahtx0.AHTx0(i2c)
                debug("[Sensor] AHTx0 initialized.")
            except Exception as e:
                debug(f"[Sensor] Init failed; using simulated readings. Error: {e}")
                self._sensor = None
        else:
            self._sensor = None

        self._sim_temp_f = float(CFG.DEFAULT_SETPOINT_F)

    def get_temp_f(self) -> float:
        if self._sensor is None:
            # Simple simulation drift
            self._sim_temp_f += 0.1
            return self._sim_temp_f

        try:
            c = float(self._sensor.temperature)
            f = (9.0 / 5.0) * c + 32.0
            if is_valid_temp_f(f):
                self.last_good_temp_f = f
            return self.last_good_temp_f
        except OSError as e:
            debug(f"[Sensor] Read error (using last good): {e}")
            return self.last_good_temp_f
        except Exception as e:
            debug(f"[Sensor] Unexpected read error (using last good): {e}")
            return self.last_good_temp_f


# -----------------------------
# Serial Reporter
# -----------------------------
class SerialReporter:
    """
    Handles sending thermostat status to a server over serial.
    Falls back to console if serial is unavailable.
    """

    def __init__(self) -> None:
        self._ser = None

        if not HARDWARE_AVAILABLE:
            debug("[Serial] Hardware libs not available. Using console output.")
            return

        try:
            self._ser = serial.Serial(
                port=CFG.SERIAL_PORT,
                baudrate=CFG.SERIAL_BAUD,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                bytesize=serial.EIGHTBITS,
                timeout=CFG.SERIAL_TIMEOUT_SEC,
            )
            debug(f"[Serial] Opened {CFG.SERIAL_PORT}.")
        except Exception as e:
            debug(f"[Serial] Could not open serial. Using console output. Error: {e}")
            self._ser = None

    def send(self, state: str, temp_f: float, setpoint_f: int) -> None:
        msg = f"{state},{temp_f:.2f},{setpoint_f}\n"
        if self._ser is None:
            debug(f"[Serial] {msg.strip()}")
            return
        try:
            self._ser.write(msg.encode("utf-8"))
        except Exception as e:
            debug(f"[Serial] Write failed (continuing): {e}")

    def close(self) -> None:
        if self._ser is not None:
            try:
                self._ser.close()
            except Exception:
                pass
        debug("[Serial] Closed.")


# -----------------------------
# State Machine
# -----------------------------
if HARDWARE_AVAILABLE:
    class TemperatureMachine(StateMachine):
        """
        State machine: off -> heat -> cool -> off
        Controls LED behavior and setpoint adjustments.
        """

        off = State(initial=True)
        heat = State()
        cool = State()

        cycle = (off.to(heat) | heat.to(cool) | cool.to(off))

        def __init__(self, sensor: TemperatureSensor, leds: "LedController") -> None:
            super().__init__()
            self.sensor = sensor
            self.leds = leds
            self.setpoint_f: int = CFG.DEFAULT_SETPOINT_F

        def on_enter_heat(self) -> None:
            debug("* Changing state to heat")
            self.update_lights()

        def on_exit_heat(self) -> None:
            self.leds.red_off()

        def on_enter_cool(self) -> None:
            debug("* Changing state to cool")
            self.update_lights()

        def on_exit_cool(self) -> None:
            self.leds.blue_off()

        def on_enter_off(self) -> None:
            debug("* Changing state to off")
            self.leds.all_off()

        def inc_setpoint(self) -> None:
            self.setpoint_f = clamp(self.setpoint_f + 1, CFG.MIN_SETPOINT_F, CFG.MAX_SETPOINT_F)
            debug(f"[Setpoint] Increased to {self.setpoint_f}")
            self.update_lights()

        def dec_setpoint(self) -> None:
            self.setpoint_f = clamp(self.setpoint_f - 1, CFG.MIN_SETPOINT_F, CFG.MAX_SETPOINT_F)
            debug(f"[Setpoint] Decreased to {self.setpoint_f}")
            self.update_lights()

        def get_temp_f(self) -> float:
            return self.sensor.get_temp_f()

        def update_lights(self) -> None:
            temp = floor(self.get_temp_f())
            debug(f"[State] {self.current_state.id} | Setpoint: {self.setpoint_f} | Temp: {temp}")

            if self.current_state.id == "off":
                self.leds.all_off()
            elif self.current_state.id == "heat":
                self.leds.blue_off()
                if temp < self.setpoint_f:
                    self.leds.red_pulse()
                else:
                    self.leds.red_on()
            elif self.current_state.id == "cool":
                self.leds.red_off()
                if temp > self.setpoint_f:
                    self.leds.blue_pulse()
                else:
                    self.leds.blue_on()
else:
    # Minimal fallback if statemachine library isn't available
    class TemperatureMachine:
        def __init__(self, sensor: TemperatureSensor, leds: "LedController") -> None:
            self.sensor = sensor
            self.leds = leds
            self.setpoint_f = CFG.DEFAULT_SETPOINT_F
            self.current_state = type("S", (), {"id": "off"})()

        def cycle(self) -> None:
            nxt = {"off": "heat", "heat": "cool", "cool": "off"}[self.current_state.id]
            self.current_state.id = nxt
            debug(f"* Changing state to {nxt}")

        def inc_setpoint(self) -> None:
            self.setpoint_f = clamp(self.setpoint_f + 1, CFG.MIN_SETPOINT_F, CFG.MAX_SETPOINT_F)

        def dec_setpoint(self) -> None:
            self.setpoint_f = clamp(self.setpoint_f - 1, CFG.MIN_SETPOINT_F, CFG.MAX_SETPOINT_F)

        def get_temp_f(self) -> float:
            return self.sensor.get_temp_f()

        def update_lights(self) -> None:
            pass


# -----------------------------
# LED Controller
# -----------------------------
class LedController:
    """
    Controls red/blue PWM LEDs. Falls back to console if unavailable.
    """

    def __init__(self) -> None:
        if HARDWARE_AVAILABLE:
            try:
                self.red = PWMLED(CFG.RED_LED_PIN)
                self.blue = PWMLED(CFG.BLUE_LED_PIN)
                self._ok = True
                debug("[LED] Initialized.")
            except Exception as e:
                debug(f"[LED] Init failed; console mode. Error: {e}")
                self._ok = False
        else:
            self._ok = False

    def all_off(self) -> None:
        if self._ok:
            self.red.off()
            self.blue.off()
        else:
            debug("[LED] all_off")

    def red_off(self) -> None:
        if self._ok:
            self.red.off()
        else:
            debug("[LED] red_off")

    def blue_off(self) -> None:
        if self._ok:
            self.blue.off()
        else:
            debug("[LED] blue_off")

    def red_on(self) -> None:
        if self._ok:
            self.red.on()
        else:
            debug("[LED] red_on")

    def blue_on(self) -> None:
        if self._ok:
            self.blue.on()
        else:
            debug("[LED] blue_on")

    def red_pulse(self) -> None:
        if self._ok:
            self.red.off()
            self.red.pulse(fade_in_time=1, fade_out_time=1, background=True)
        else:
            debug("[LED] red_pulse")

    def blue_pulse(self) -> None:
        if self._ok:
            self.blue.off()
            self.blue.pulse(fade_in_time=1, fade_out_time=1, background=True)
        else:
            debug("[LED] blue_pulse")


# -----------------------------
# Thermostat Controller
# -----------------------------
class ThermostatController:
    """
    Coordinates machine state, display updates, and serial reporting.
    """

    def __init__(self) -> None:
        self.shutdown_event = Event()
        self.display = ManagedDisplay()
        self.sensor = TemperatureSensor()
        self.leds = LedController()
        self.serial = SerialReporter()
        self.machine = TemperatureMachine(self.sensor, self.leds)

        self._display_thread = Thread(target=self._display_loop, daemon=True)
        self._seconds = 0

    def start(self) -> None:
        debug("[Controller] Starting display thread.")
        self._display_thread.start()
        self._setup_buttons()
        debug("[Controller] Running main loop. Press CTRL-C to exit.")
        self._main_loop()

    def _setup_buttons(self) -> None:
        if not HARDWARE_AVAILABLE:
            debug("[Buttons] Hardware unavailable; buttons disabled in simulation.")
            return

        try:
            mode_btn = Button(CFG.MODE_BUTTON_PIN)
            inc_btn = Button(CFG.INC_BUTTON_PIN)
            dec_btn = Button(CFG.DEC_BUTTON_PIN)

            mode_btn.when_pressed = self._on_mode_pressed
            inc_btn.when_pressed = self._on_inc_pressed
            dec_btn.when_pressed = self._on_dec_pressed

            debug("[Buttons] Configured.")
        except Exception as e:
            debug(f"[Buttons] Failed to configure buttons: {e}")

    def _on_mode_pressed(self) -> None:
        debug("[Input] Mode button pressed.")
        # statemachine uses event name 'cycle' when available
        if hasattr(self.machine, "cycle") and callable(getattr(self.machine, "cycle")):
            self.machine.cycle()  # type: ignore
        self.machine.update_lights()

    def _on_inc_pressed(self) -> None:
        debug("[Input] Increase button pressed.")
        self.machine.inc_setpoint() if hasattr(self.machine, "inc_setpoint") else None  # type: ignore

    def _on_dec_pressed(self) -> None:
        debug("[Input] Decrease button pressed.")
        self.machine.dec_setpoint() if hasattr(self.machine, "dec_setpoint") else None  # type: ignore

    def _display_loop(self) -> None:
        alt = 0
        while not self.shutdown_event.is_set():
            now = datetime.now()
            line1 = now.strftime("%m/%d/%Y %H:%M")

            temp_f = self.machine.get_temp_f()
            state = self.machine.current_state.id
            setpoint = getattr(self.machine, "setpoint_f", CFG.DEFAULT_SETPOINT_F)

            if alt < 5:
                line2 = f"Temp: {temp_f:.1f}F"
            else:
                line2 = f"{state} {setpoint}F"
            alt = (alt + 1) % 10

            self.display.update(line1, line2)
            sleep(CFG.DISPLAY_REFRESH_SEC)

    def _main_loop(self) -> None:
        try:
            while not self.shutdown_event.is_set():
                sleep(1)
                self._seconds += 1

                # Periodic lights refresh (helps keep PWM behavior consistent)
                if self._seconds % 10 == 0:
                    self.machine.update_lights()

                # Periodic server reporting
                if self._seconds % CFG.SERVER_REPORT_EVERY_SEC == 0:
                    temp_f = self.machine.get_temp_f()
                    state = self.machine.current_state.id
                    setpoint = getattr(self.machine, "setpoint_f", CFG.DEFAULT_SETPOINT_F)
                    self.serial.send(state, temp_f, int(setpoint))
        except KeyboardInterrupt:
            debug("[Controller] KeyboardInterrupt received. Shutting down.")
            self.stop()
        except Exception as e:
            debug(f"[Controller] Fatal error: {e}")
            self.stop()

    def stop(self) -> None:
        self.shutdown_event.set()
        try:
            self._display_thread.join(timeout=2.0)
        except Exception:
            pass

        # Turn everything off / cleanup
        try:
            self.leds.all_off()
        except Exception:
            pass

        try:
            self.serial.close()
        except Exception:
            pass

        try:
            self.display.cleanup()
        except Exception:
            pass

        debug("[Controller] Shutdown complete.")


def main() -> None:
    controller = ThermostatController()
    controller.start()


if __name__ == "__main__":
    main()
